CREATE PROCEDURE get_learner(IN id INT)
  BEGIN
	SELECT *
	FROM learners
	WHERE learners.id = id;
END;
