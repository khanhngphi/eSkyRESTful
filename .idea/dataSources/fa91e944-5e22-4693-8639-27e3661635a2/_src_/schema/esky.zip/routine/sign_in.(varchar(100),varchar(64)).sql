CREATE PROCEDURE sign_in(IN email VARCHAR(100), IN password VARCHAR(64))
  BEGIN
	DECLARE id VARCHAR(64);
	DECLARE true_pass VARCHAR(64);
    SELECT accounts.id, accounts.password INTO id, true_pass FROM accounts WHERE accounts.email = email;
	IF true_pass IS NOT NULL THEN
    BEGIN
		IF true_pass = password THEN
			SELECT id;
		ELSE
			SELECT -1;
		END IF;
	END;
    ELSE
		SELECT -2;
	END IF;
END;
