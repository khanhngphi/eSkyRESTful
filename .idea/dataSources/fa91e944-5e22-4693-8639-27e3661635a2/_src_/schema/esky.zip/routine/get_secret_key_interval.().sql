CREATE FUNCTION get_secret_key_interval()
  RETURNS INT
  BEGIN
	RETURN (SELECT application_policies.value 
		   from application_policies 
           where application_policies.name = 'secret_key_interval');
END;
