CREATE PROCEDURE get_lesson_questions(IN id INT)
  BEGIN
	select questions.id, questions.question, questions.phrase, questions.voice, questions.picture, questions.answerType, questions.answers, questions.choices
    from questions, lessons_questions
    where questions.id = lessons_questions.question and lessons_questions.lesson = id;
END;
