CREATE FUNCTION check_password(id INT, password CHAR(64))
  RETURNS INT
  BEGIN 
    IF EXISTS (SELECT * FROM accounts WHERE accounts.id = id AND accounts.password = password) THEN 
      RETURN 1;
    ELSE 
      RETURN 0;
    END IF;
  END;
