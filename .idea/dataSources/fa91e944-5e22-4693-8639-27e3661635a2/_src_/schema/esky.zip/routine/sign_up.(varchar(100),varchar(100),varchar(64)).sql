CREATE PROCEDURE sign_up(IN email VARCHAR(100), IN name VARCHAR(100), IN password VARCHAR(64))
  BEGIN
	DECLARE id INT;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
	BEGIN
		ROLLBACK;
		SELECT -1;
	END;
	DECLARE EXIT HANDLER FOR SQLWARNING 
	BEGIN
		ROLLBACK;
		SELECT -2;
	END;
	DECLARE EXIT HANDLER FOR NOT FOUND 
	BEGIN
		ROLLBACK;
		SELECT -3;
	END;
	SET autocommit = 0;
    START TRANSACTION;
    BEGIN
    INSERT INTO accounts(email, name, password, role, secretKey) VALUES (email, name, password, "user", generate_key());
    SET id = (SELECT LAST_INSERT_ID());
    INSERT INTO learners(id) VALUES (id);
    UPDATE interactive_statistics
    SET sign_up = sign_up + 1
    WHERE time = (SELECT MAX(time) FROM (SELECT time FROM interactive_statistics) AS times);
    COMMIT;
    SELECT id;
    END;
END;
