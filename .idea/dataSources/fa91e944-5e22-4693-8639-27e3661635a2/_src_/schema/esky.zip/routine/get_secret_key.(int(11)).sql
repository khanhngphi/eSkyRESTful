CREATE PROCEDURE get_secret_key(IN id INT)
  BEGIN
    declare lastChange date;
    set lastChange = (select accounts.lastChange from accounts where accounts.id = id);
    if now() > lastChange + interval get_secret_key_interval() day then
    begin
		update accounts
		set secretKey = generate_key(), lastChange = now()
		where accounts.id = id;
		select secretKey from accounts where accounts.id = id;
	end;
    else
		select secretKey from accounts where accounts.id = id;
	end if;
END;
