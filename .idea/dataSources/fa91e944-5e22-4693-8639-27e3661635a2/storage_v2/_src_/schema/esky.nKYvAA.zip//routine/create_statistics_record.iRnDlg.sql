CREATE PROCEDURE create_statistics_record()
  BEGIN
	INSERT INTO interactive_statistics(time) VALUES (NOW());
END;
