CREATE PROCEDURE get_level_info()
  BEGIN
	DECLARE seed DOUBLE;
	DECLARE factor DOUBLE;
    SET seed = (SELECT application_policies.value
						         FROM application_policies
							     WHERE application_policies.name = 'level_experience_seed');
    SET factor = (SELECT application_policies.value
					    FROM application_policies
						WHERE application_policies.name = 'level_factor');
	SELECT seed, factor;
END;
