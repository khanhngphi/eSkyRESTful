CREATE TRIGGER learners_lessons_BEFORE_INSERT
BEFORE INSERT ON learners_lessons
FOR EACH ROW
  BEGIN
	SET new.remains = create_lesson_remains(new.lesson);
END;
