CREATE FUNCTION get_lesson_experience(id INT)
  RETURNS INT
  BEGIN
	RETURN (SELECT SUM(`difficulty_levels`.`experience` * `answer_types`.`experienceFactor`)
			FROM lessons_questions, questions, answer_types, difficulty_levels
			WHERE lessons_questions.`lesson` = id
			AND lessons_questions.`question` = questions.`id`
			AND questions.`answerType` = answer_types.`type`
			AND questions.`difficulty` = `difficulty_levels`.`level`);
END;
