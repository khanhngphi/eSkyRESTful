CREATE TRIGGER accounts_BEFORE_INSERT
BEFORE INSERT ON accounts
FOR EACH ROW
  BEGIN
	set new.last_change = now();
END;
