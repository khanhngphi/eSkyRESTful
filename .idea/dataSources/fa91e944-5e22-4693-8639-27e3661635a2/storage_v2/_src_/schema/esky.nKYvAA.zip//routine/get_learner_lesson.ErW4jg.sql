CREATE PROCEDURE get_learner_lesson(IN id INT, IN lessonId INT)
  BEGIN
	SELECT lessons.id, lessons.`subject`, lessons.`title`, lessons.`caption`, lessons.`description`, lessons.`level`, learners_lessons.`answered`, learners_lessons.`remains`, learners_lessons.`passed`, get_lesson_experience(lessonId) AS `experience`
	FROM lessons, learners_lessons
	WHERE lessons.id = learners_lessons.lesson 
    AND learners_lessons.learner = id
    AND learners_lessons.lesson = lessonId;
END;
