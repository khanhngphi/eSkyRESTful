CREATE PROCEDURE update_secret_key(IN id INT)
  BEGIN
  DECLARE check_id char(5);
  DECLARE secretKey char(10);
    SET check_id = (SELECT accounts.id FROM accounts WHERE accounts.id = id);
  IF check_id IS NOT NULL THEN
      SET secretKey = generate_key();
    UPDATE accounts
      SET accounts.secretKey = secretKey, accounts.lastChange = now()
      WHERE accounts.id = id;
    SELECT secretKey;
  END IF;
END;
