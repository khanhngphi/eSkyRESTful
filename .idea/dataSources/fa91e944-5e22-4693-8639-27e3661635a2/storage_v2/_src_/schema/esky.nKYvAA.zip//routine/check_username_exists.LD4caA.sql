CREATE FUNCTION check_username_exists(username VARCHAR(104))
  RETURNS INT
  BEGIN
    IF EXISTS (SELECT * FROM accounts WHERE TRIM(LOWER(accounts.username)) = TRIM(LOWER(username))) THEN
      RETURN 1;
    ELSE
      RETURN 0;
    END IF;
  END;
