CREATE PROCEDURE pass_lesson(IN id INT, IN lessonId INT)
  BEGIN
	update learners_lessons
    set passed = 1, answered = null, remains = create_lesson_remains(lessonId)
    where learner = id and lesson = lessonId;
    update learners
    set learners.experience = learners.experience + get_lesson_experience(lessonId)
    where learners.id = id;
END;
