CREATE FUNCTION create_lesson_remains(id INT)
  RETURNS VARCHAR(200)
  BEGIN
	RETURN (SELECT GROUP_CONCAT(question SEPARATOR ';')
	        FROM lessons_questions
	        WHERE lesson = id);
    END;
